import java.util.HashMap;
import java.util.Scanner;

public class sistema {
	
	static Scanner scan = new Scanner(System.in);
	static int opcion = -1;
	static int e = -1;

	public static void main(String[] args) {
		
		HashMap<String,eventos> listaEventos = new HashMap<String,eventos>();
		
		usuario obj1 = new usuario();
		String ingresado;
		int int_ingresado;
		System.out.println(" 1- Ingresar sesión\n 2- Eventos\n 3- Comprar entrada\n 0- Salir\n");
		System.out.println("Ingrese opción:");
		opcion = Integer.parseInt(scan.nextLine());
		
		while (true) {
			
			if (opcion == 1) {
				
				System.out.println("Ingrese los datos socilitados:");
	        	System.out.println("Nombre y apellido (todo en minuscula):");
	        	ingresado = scan.nextLine();
	        	obj1.setNombre_usuario(ingresado);
	        	System.out.println("Edad:");
	        	int_ingresado = Integer.parseInt(scan.nextLine());
	        	obj1.setEdad(int_ingresado);
	        	System.out.println("Número de celular:");
	        	int_ingresado = Integer.parseInt(scan.nextLine());
	        	obj1.setTelefono(int_ingresado);
	        	System.out.println("Cuidad donde recide:");
	        	ingresado = scan.nextLine();
	        	obj1.setUbicacion_usuario(ingresado);
	        	
	        	saludar(obj1.getNombre_usuario());
	        	
				
			}
			if (opcion == 2) {
				System.out.println(" 1- Lista de eventos\n 2- Buscar eventos\n 3- Filtrar eventos\n 0- Volver al menu principal\n");
				e = Integer.parseInt(scan.nextLine());
				
				if(e == 1) {
					System.out.println("lista de eventos");
				}
				if(e == 2) {
					System.out.println("Buscar eventos");
				}
				if(e == 3) {
					System.out.println("Filtrar eventos");
				}
				if (e == 0) {
					System.out.println("Salir al menu principal");
				}
			}
			if (opcion == 3) {
				
			}
			if (opcion == 0) {
				break;
			}
			
			System.out.println(" 1- Ingresar sesión\n 2- Eventos\n 3- Comprar entrada\n 4- Salir\n");
			System.out.println("Ingrese opción:");
			opcion = Integer.parseInt(scan.nextLine());
			
			
			if (opcion > 4 || opcion < 0) {
				System.out.println("ERROR:\ningrese una de las siguientes opciones");
				System.out.println(" 1- Ingresar sesión\n 2- Eventos\n 3- Comprar entrada\n 0- Salir\n");
				opcion = Integer.parseInt(scan.nextLine());
			}
			
		}
	
	}
	
	static void saludar(String nombre){
	    System.out.println("Hola "+ nombre+" te has registrado con éxito :) \n");
	    System.out.println("MENU PRINCIPAL:\n");
	}
	
	

}

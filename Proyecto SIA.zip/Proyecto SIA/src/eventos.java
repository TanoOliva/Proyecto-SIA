
import java.util.List;

public class eventos {
	
	private String nombre_evento;
	private String ubicacion_evento;
	private String tipo_evento;
	private int stock;
	private String hora;
	private int fecha;
	
	
	public String getNombre_evento() {
		return nombre_evento;
	}
	public void setNombre_evento(String nombre_evento) {
		this.nombre_evento = nombre_evento;
	}
	public String getUbicacion_evento() {
		return ubicacion_evento;
	}
	public void setUbicacion_evento(String ubicacion_evento) {
		this.ubicacion_evento = ubicacion_evento;
	}
	public String getTipo_evento() {
		return tipo_evento;
	}
	public void setTipo_evento(String tipo_evento) {
		this.tipo_evento = tipo_evento;
	}
	public int getStock() {
		return stock;
	}
	public void setStock(int stock) {
		this.stock = stock;
	}
	public String getHora() {
		return hora;
	}
	public void setHora(String hora) {
		this.hora = hora;
	}
	public int getFecha() {
		return fecha;
	}
	public void setFecha(int fecha) {
		this.fecha = fecha;
	}
	
	
	
	
	

	

}



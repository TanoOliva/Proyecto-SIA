
public class usuario {
	
	private String nombre_usuario;
	private int edad;
	private int telefono;
	private String ubicacion_usuario;
	private String correo_usuario;
	private String preferencias_usuario;
	
	
	public String getNombre_usuario() {
		return nombre_usuario;
	}
	public void setNombre_usuario(String nombre_usuario) {
		this.nombre_usuario = nombre_usuario;
	}
	public int getEdad() {
		return edad;
	}
	public void setEdad(int edad) {
		this.edad = edad;
	}
	public int getTelefono() {
		return telefono;
	}
	public void setTelefono(int telefono) {
		this.telefono = telefono;
	}
	public String getUbicacion_usuario() {
		return ubicacion_usuario;
	}
	public void setUbicacion_usuario(String ubicacion_usuario) {
		this.ubicacion_usuario = ubicacion_usuario;
	}
	public String getCorreo_usuario() {
		return correo_usuario;
	}
	public void setCorreo_usuario(String correo_usuario) {
		this.correo_usuario = correo_usuario;
	}
	public String getPreferencias_usuario() {
		return preferencias_usuario;
	}
	public void setPreferencias_usuario(String preferencias_usuario) {
		this.preferencias_usuario = preferencias_usuario;
	}
	
	
	
	

}
